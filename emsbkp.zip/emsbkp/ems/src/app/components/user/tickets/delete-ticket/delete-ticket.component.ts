import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-ticket',
  imports: [],
  templateUrl: './delete-ticket.component.html',
  styleUrl: './delete-ticket.component.css'
})
export class DeleteTicketComponent {

}
