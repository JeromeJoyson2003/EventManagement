﻿namespace EventManagementAPI.Models.DTOs
{
    public class TicketDetailsDto
    {
        public int TicketID { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string UserContactNumber { get; set; }
        public int EventID { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public string CategoryName { get; set; }
        public string LocationName { get; set; }
        public string LocationAddress { get; set; }
        public string LocationCity { get; set; }
        public DateTime EventStartDate { get; set; }
        public DateTime EventEndDate { get; set; }
        public DateTime BookingDate { get; set; }
        public string Status { get; set; }
        public string BookingStatus { get; set; } // Additional booking status
        public int TicketCount { get; set; }
        public decimal? EventPrice { get; set; }
        public bool IsEventPaid { get; set; }
    }
}
