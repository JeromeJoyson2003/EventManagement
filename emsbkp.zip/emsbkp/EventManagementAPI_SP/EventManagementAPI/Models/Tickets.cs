﻿namespace EventManagementAPI.Models
{
    public class Tickets
    {

        public int TicketID { get; set; }
        public int EventID { get; set; }
        //public Event Event { get; set; }
        public int UserID { get; set; }
        //public User User { get; set; }
        public DateTime BookingDate { get; set; }
        public string? Status { get; set; }
        public int TicketCount { get; set; }
        public Feedbacks Feedback { get; set; }



    }
}
