﻿using EventManagementAPI.Models;
using EventManagementAPI.Models.DTOs;

namespace EventManagementAPI.Services
{
    public interface IUserService
    {
        Task<bool> RegisterUserAsync(UserRegisterDto dto);
        Task<User?> LoginUserAsync(string email, string password);
        Task<bool> UpdateUserAsync(int userId, UserRegisterDto dto);
        Task<List<User>> GetAllUsersAsync();
        Task<bool> DeleteUserAsync(int userId);
        Task<bool> UpdateSelfAsync(int userId, UserRegisterDto dto);
        Task<User?> GetUserByIdAsync(int userId);
        Task<bool> UpdateUserDetailsAsync(int userId, string name, string contactNumber);

    }
}