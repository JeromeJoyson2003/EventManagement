﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;

namespace EventManagementAPI.Services
{
    public class LocationService
    {
        private readonly UserDbContext _context;

        public LocationService(UserDbContext context)
        {
            _context = context;
        }

        public List<Location> GetLocationDetails()
        {
            return _context.Locations.ToList();
        }

        public void RemoveLocationDetails(int id)
        {
            var location = _context.Locations.Find(id);
            if (location != null)
            {
                _context.Locations.Remove(location);
                _context.SaveChanges();
            }
        }

        public void UpdateLocationDetails(Location location, int id)
        {
            var existingLocation = _context.Locations.Find(id);
            if (existingLocation != null)
            {
                existingLocation.LocationName = location.LocationName;
                existingLocation.Capacity = location.Capacity;
                existingLocation.Address = location.Address;
                existingLocation.City = location.City;
                existingLocation.State = location.State;
                existingLocation.Country = location.Country;
                existingLocation.PostalCode = location.PostalCode;
                existingLocation.PrimaryContact = location.PrimaryContact;
                existingLocation.SecondaryContact = location.SecondaryContact;

                _context.SaveChanges();
            }
        }

        public void EnterLocationDetails(Location location)
        {
            _context.Locations.Add(location);
            _context.SaveChanges();
        }
    }
}
