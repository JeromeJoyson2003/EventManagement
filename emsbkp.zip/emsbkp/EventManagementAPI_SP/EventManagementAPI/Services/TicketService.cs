﻿using EventManagementAPI.Data;
using EventManagementAPI.Models.DTOs;
using Microsoft.EntityFrameworkCore;

namespace EventManagementAPI.Services
{
    public class TicketService : ITicketService
    {
        private readonly UserDbContext _context;

        public TicketService(UserDbContext context)
        {
            _context = context;
        }

        public async Task<List<TicketDetailsDto>> GetAllTicketDetailsAsync()
        {
            var ticketDetails = await GetTicketDetailsQuery().ToListAsync();
            return ticketDetails;
        }

        public async Task<List<TicketDetailsDto>> GetTicketsByUserIdAsync(int userId)
        {
            var ticketDetails = await GetTicketDetailsQuery()
                .Where(ticket => ticket.UserID == userId)
                .ToListAsync();
            return ticketDetails;
        }

        public async Task<TicketDetailsDto?> GetTicketByIdAsync(int ticketId)
        {
            var ticketDetail = await GetTicketDetailsQuery()
                .Where(ticket => ticket.TicketID == ticketId)
                .FirstOrDefaultAsync();
            return ticketDetail;
        }

        public async Task<bool> IsTicketBookedAsync(int userId, int eventId)
        {
            return await _context.Tickets
                .AnyAsync(t => t.UserID == userId && t.EventID == eventId && t.Status == "Confirmed");
        }

        private IQueryable<TicketDetailsDto> GetTicketDetailsQuery()
        {
            return from ticket in _context.Tickets
                   join user in _context.Users on ticket.UserID equals user.UserID
                   join eventItem in _context.Events on ticket.EventID equals eventItem.EventID
                   join location in _context.Locations on eventItem.LocationID equals location.LocationID
                   join category in _context.Categories on eventItem.CategoryID equals category.CategoryID
                   select new TicketDetailsDto
                   {
                       TicketID = ticket.TicketID,
                       UserID = ticket.UserID,
                       UserName = user.Name,
                       UserEmail = user.Email,
                       UserContactNumber = user.ContactNumber,
                       EventID = ticket.EventID,
                       EventName = eventItem.Name,
                       EventDescription = eventItem.Description,
                       CategoryName = category.CategoryName,
                       LocationName = location.LocationName,
                       LocationAddress = location.Address,
                       LocationCity = location.City,
                       EventStartDate = eventItem.StartDate,
                       EventEndDate = eventItem.EndDate,
                       BookingDate = ticket.BookingDate,
                       Status = ticket.Status,
                       TicketCount = ticket.TicketCount,
                       EventPrice = eventItem.Price,
                       IsEventPaid = eventItem.IsPrice,
                       BookingStatus = ticket.Status // Additional booking status field
                   };
        }
    }
}
