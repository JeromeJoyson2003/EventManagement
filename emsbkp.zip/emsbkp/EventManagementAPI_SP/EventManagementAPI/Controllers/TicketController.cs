﻿using EventManagementAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TicketController : ControllerBase
    {
        private readonly ITicketService _ticketService;

        public TicketController(ITicketService ticketService)
        {
            _ticketService = ticketService;
        }

        [HttpGet("all-details")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllTicketDetails()
        {
            var tickets = await _ticketService.GetAllTicketDetailsAsync();

            if (tickets == null || !tickets.Any())
            {
                return NotFound(new { message = "No tickets found." });
            }

            return Ok(tickets);
        }

        [HttpGet("user/{userId}")]
        //[Authorize]
        public async Task<IActionResult> GetTicketsByUserId(int userId)
        {
            if (userId <= 0)
            {
                return BadRequest(new { message = "Invalid user ID. User ID must be a positive integer." });
            }

            var tickets = await _ticketService.GetTicketsByUserIdAsync(userId);

            if (tickets == null || !tickets.Any())
            {
                return NotFound(new { message = "No tickets found for the specified user." });
            }

            return Ok(tickets);
        }

        [HttpGet("{ticketId}")]
        //[Authorize]
        public async Task<IActionResult> GetTicketById(int ticketId)
        {
            if (ticketId <= 0)
            {
                return BadRequest(new { message = "Invalid ticket ID. Ticket ID must be a positive integer." });
            }

            var ticket = await _ticketService.GetTicketByIdAsync(ticketId);

            if (ticket == null)
            {
                return NotFound(new { message = "Ticket not found." });
            }

            return Ok(ticket);
        }

        [HttpGet("is-booked/{userId}/{eventId}")]
        //[Authorize]
        public async Task<IActionResult> IsTicketBooked(int userId, int eventId)
        {
            if (userId <= 0 || eventId <= 0)
            {
                return BadRequest(new { message = "Invalid user ID or event ID. Both must be positive integers." });
            }

            var isBooked = await _ticketService.IsTicketBookedAsync(userId, eventId);

            return Ok(new
            {
                userId = userId,
                eventId = eventId,
                isBooked = isBooked
            });
        }
    }
}
