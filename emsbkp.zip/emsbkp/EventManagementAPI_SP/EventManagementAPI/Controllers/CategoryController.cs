﻿using EventManagementAPI.Models;
using EventManagementAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly CategoryServices _categoryServices;

        public CategoriesController(CategoryServices categoryServices)
        {
            _categoryServices = categoryServices;
        }

        // GET: api/Categories
        [HttpGet]
        //[Authorize(Roles = "User,Organizer,Admin")]
        public IActionResult GetAllCategories()
        {
            var categories = _categoryServices.GetAllCategories();
            return Ok(categories);
        }

        // GET: api/Categories/{id}
        [HttpGet("{id}")]
        //[Authorize(Roles = "User")]
        public IActionResult GetCategory(int id)
        {
            var category = _categoryServices.GetCategory(id);
            if (category == null)
                return NotFound();

            return Ok(category);
        }

        // POST: api/Categories
        [HttpPost]
        //[Authorize(Roles = "Organizer,Admin")]
        public IActionResult AddCategory([FromBody] Category category)
        {
            if (category == null || string.IsNullOrEmpty(category.CategoryName))
            {
                return BadRequest("Invalid category data.");
            }

            _categoryServices.AddCategory(category);
            return Ok("Category added successfully.");
        }
    }
}