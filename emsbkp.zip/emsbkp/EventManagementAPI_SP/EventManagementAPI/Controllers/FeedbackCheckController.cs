﻿using EventManagementAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementAPI.Controllers
{
    [ApiController]
    [Route("api/feedback-check")]
    public class FeedbackCheckController : ControllerBase
    {
        private readonly FeedbackService _feedbackService;

        public FeedbackCheckController(FeedbackService feedbackService)
        {
            _feedbackService = feedbackService;
        }

        [HttpGet("user/{userId}/event/{eventId}")]
        //[Authorize]
        public IActionResult CheckUserFeedbackForEvent(int userId, int eventId)
        {
            if (userId <= 0 || eventId <= 0)
            {
                return BadRequest(new { message = "Invalid user ID or event ID. Both must be positive integers." });
            }

            // First check if user has booked the event
            var hasBookedEvent = _feedbackService.IsEventBookedByUser(userId, eventId);
            if (!hasBookedEvent)
            {
                return BadRequest(new
                {
                    message = "User has not booked this event.",
                    hasGivenFeedback = false,
                    canGiveFeedback = false,
                    reason = "Event not booked"
                });
            }

            // Get ticket ID for the user and event
            var ticketId = _feedbackService.GetTicketIdByUserAndEvent(userId, eventId);
            if (ticketId == null)
            {
                return NotFound(new
                {
                    message = "No ticket found for this user and event.",
                    hasGivenFeedback = false,
                    canGiveFeedback = false,
                    reason = "Ticket not found"
                });
            }

            // Check if feedback already exists for this ticket
            var hasGivenFeedback = _feedbackService.FeedbackExistsByTicketId(ticketId.Value);

            return Ok(new
            {
                userId = userId,
                eventId = eventId,
                ticketId = ticketId.Value,
                hasGivenFeedback = hasGivenFeedback,
                canGiveFeedback = !hasGivenFeedback, // Can give feedback only if not already given
                message = hasGivenFeedback ? "Feedback already submitted for this event." : "User can submit feedback for this event."
            });
        }

        [HttpGet("ticket/{ticketId}/status")]
        //[Authorize]
        public IActionResult CheckFeedbackByTicketId(int ticketId)
        {
            if (ticketId <= 0)
            {
                return BadRequest(new { message = "Invalid ticket ID. Ticket ID must be a positive integer." });
            }

            var feedbackExists = _feedbackService.FeedbackExistsByTicketId(ticketId);

            return Ok(new
            {
                ticketId = ticketId,
                hasGivenFeedback = feedbackExists,
                canGiveFeedback = !feedbackExists,
                message = feedbackExists ? "Feedback already exists for this ticket." : "No feedback found for this ticket."
            });
        }

        [HttpGet("user/{userId}/all-feedback-status")]
        //[Authorize]
        public IActionResult GetAllUserFeedbackStatus(int userId)
        {
            if (userId <= 0)
            {
                return BadRequest(new { message = "Invalid user ID. User ID must be a positive integer." });
            }

            var feedbackStatus = _feedbackService.GetUserFeedbackStatusForAllEvents(userId);

            if (feedbackStatus == null || !feedbackStatus.Any())
            {
                return NotFound(new { message = "No booking history found for this user." });
            }

            return Ok(feedbackStatus);
        }
    }
}
