﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;

namespace EventManagementAPI.Services
{
    public class NotificationServices
    {
        private readonly UserDbContext _context;

        public NotificationServices(UserDbContext context)
        {
            _context = context;
        }

        public void SendNotification(int userId, int eventId, bool bookingStatus, string eventName, DateTime eventDate, string customMessage = null)
        {
            var message = customMessage ?? (bookingStatus
                ? $"Your booking for {eventName} on {eventDate} is confirmed."
                : $"Your booking for {eventName} on {eventDate} failed.");

            var notification = new Notifications
            {
                UserID = userId,
                EventID = eventId,
                Message = message,
                SentTimestamp = DateTime.Now
            };

            _context.Notifications.Add(notification);
            _context.SaveChanges();
        }

        public List<Notifications> GetNotificationsByUserId(int userId)
        {
            return _context.Notifications
                .Where(n => n.UserID == userId)
                .OrderByDescending(n => n.SentTimestamp)
                .ToList();
        }
    }
}
