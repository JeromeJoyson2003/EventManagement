﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;
using System;

namespace EventManagementAPI.Services
{
    public class FeedbackService
    {

        private readonly UserDbContext _adc;
        public FeedbackService(UserDbContext ad)
        {
            _adc = ad;
        }
        #region AddFeedback
        public void AddFeedback(FeedbackDTO feed, int userId, int ticketId)
        {
            // Retrieve ticket using provided TicketID
            Tickets ticket = _adc.Tickets.FirstOrDefault(t => t.TicketID == ticketId && t.UserID == userId);

            if (ticket != null)
            {
                // Automatically retrieve the event linked to this ticket
                Event e = _adc.Events.FirstOrDefault(ev => ev.EventID == ticket.EventID);

                if (e != null)
                {
                    Feedbacks fe = new Feedbacks
                    {
                        EventID = e.EventID, // Automatically determined from Ticket
                        TicketID = ticket.TicketID, // Taken from user input
                        Rating = feed.Rating,
                        Comments = feed.Comments,
                        SubmittedTimestamp = DateTime.UtcNow,
                        UserID = userId // Provided by user
                    };

                    _adc.Feedbacks.Add(fe);
                    _adc.SaveChanges();
                }
            }
        }

        public int? GetTicketIdByUserAndEvent(int userId, int eventId)
        {
            return _adc.Tickets
                .Where(t => t.UserID == userId && t.EventID == eventId)
                .Select(t => t.TicketID)
                .FirstOrDefault();
        }


        #endregion

        #region ViewFeedbacks
        public List<object> ViewFeedbacksWithUserNames(int eventId)
        {
            var feedbacksWithUsers = _adc.Feedbacks
                .Where(f => f.EventID == eventId)
                .Join(_adc.Users,
                      feedback => feedback.UserID,
                      user => user.UserID,
                      (feedback, user) => new
                      {
                          feedback.FeedbackID,
                          feedback.EventID,
                          feedback.UserID,
                          UserName = user.Name,
                          feedback.Rating,
                          feedback.Comments,
                          feedback.SubmittedTimestamp
                      })
                .ToList<object>();

            return feedbacksWithUsers;
        }

        public object GetFeedbackByIdWithUserName(int feedbackId)
        {
            var feedbackDetails = (from feedback in _adc.Feedbacks
                                   join user in _adc.Users on feedback.UserID equals user.UserID
                                   where feedback.FeedbackID == feedbackId
                                   select new
                                   {
                                       FeedbackID = feedback.FeedbackID,
                                       EventID = feedback.EventID,
                                       UserID = feedback.UserID,
                                       UserName = user.Name, // Include user name
                                       Rating = feedback.Rating,
                                       Comments = feedback.Comments,
                                       SubmittedTimestamp = feedback.SubmittedTimestamp,
                                       TicketID = feedback.TicketID
                                   }).FirstOrDefault();

            return feedbackDetails;
        }

        #endregion 
        public double GetAverageRating(int eventId)
        {
            var feedbacksForEvent = _adc.Feedbacks
                                        .Where(f => f.EventID == eventId);

            if (feedbacksForEvent.Any())
            {
                return feedbacksForEvent.Average(f => f.Rating);
            }
            return 0;
        }
        public Dictionary<int, int> GetRatingCounts(int eventId)
        {
            var ratingCounts = new Dictionary<int, int>();

            for (int i = 1; i <= 5; i++)
            {
                ratingCounts[i] = _adc.Feedbacks.Count(f => f.EventID == eventId && f.Rating == i);
            }

            return ratingCounts;
        }
        public bool DeleteFeedbacks(int id, int eventid)
        {
            var feedback = _adc.Feedbacks.FirstOrDefault(f => f.FeedbackID == id && f.EventID == eventid);
            if (feedback == null)
            {
                return false;
            }

            try
            {
                _adc.Feedbacks.Remove(feedback);
                _adc.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                // Log the error for debugging purposes
                Console.WriteLine($"Error deleting feedback: {ex.Message}");
                return false;
            }
        }
        public bool FeedbackExistsByTicketId(int ticketId)
        {
            return _adc.Feedbacks.Any(f => f.TicketID == ticketId);
        }
        public bool IsEventBookedByUser(int userId, int eventId)
        {
            return _adc.Tickets.Any(t => t.UserID == userId && t.EventID == eventId);
        }

        public class FeedbackDTO
        {


            //public int UserID { get; set; }

            public int Rating { get; set; }
            public string Comments { get; set; }
            //public DateTime SubmittedTimestamp { get; set; }// = DateTime.UtcNow;

        }
    }
}
