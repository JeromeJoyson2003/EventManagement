﻿using EventManagementAPI.Data;
using EventManagementAPI.Models;
using EventManagementAPI.Services;

namespace EventManagementAPI.Services
{
    public class BookingService
    {
        private readonly UserDbContext _context;
        private readonly NotificationServices _notificationServices;

        public BookingService(UserDbContext context, NotificationServices notificationServices)
        {
            _context = context;
            _notificationServices = notificationServices;
        }

        public string ProcessTicketBooking(int userId, int eventId, int ticketCount)
        {
            var evnt = _context.Events.FirstOrDefault(e => e.EventID == eventId);
            if (evnt == null)
                return "Event not found.";

            if (DateTime.UtcNow > evnt.EndDate)
                return "Cannot book the event as it is already completed.";

            var location = _context.Locations.FirstOrDefault(l => l.LocationID == evnt.LocationID);
            if (location == null)
                return "Location not found.";

            if (evnt.BookedCapacity + ticketCount > location.Capacity)
                return "Capacity is full. Cannot book the ticket for the event.";

            var ticket = new Tickets
            {
                EventID = eventId,
                UserID = userId,
                BookingDate = DateTime.UtcNow,
                Status = "Confirmed",
                TicketCount = ticketCount
            };

            evnt.BookedCapacity += ticketCount;

            _context.Tickets.Add(ticket);
            _context.Events.Update(evnt);
            _context.SaveChanges();

            _notificationServices.SendNotification(userId, eventId, true, evnt.Name, evnt.StartDate);

            return "Ticket booked successfully.";
        }

        public string CancelTicketBooking(int userId, int eventId)
        {
            var ticket = _context.Tickets.FirstOrDefault(t => t.UserID == userId && t.EventID == eventId && t.Status == "Confirmed");
            if (ticket == null)
                return "No confirmed booking found for the given user and event.";

            var evnt = _context.Events.FirstOrDefault(e => e.EventID == eventId);
            if (evnt != null)
            {
                evnt.BookedCapacity -= ticket.TicketCount;
                _context.Events.Update(evnt);
            }

            ticket.Status = "Cancelled";
            _context.Tickets.Update(ticket);
            _context.SaveChanges();

            _notificationServices.SendNotification(userId, eventId, false, evnt?.Name ?? "Event", evnt?.StartDate ?? DateTime.UtcNow, "Your ticket has been cancelled.");

            return "Ticket cancelled successfully.";
        }

        public string GetLatestBookingStatus(int userId, int eventId)
        {
            var ticket = _context.Tickets
                .Where(t => t.UserID == userId && t.EventID == eventId)
                .OrderByDescending(t => t.BookingDate)
                .FirstOrDefault();

            return ticket?.Status;
        }
    }
}
