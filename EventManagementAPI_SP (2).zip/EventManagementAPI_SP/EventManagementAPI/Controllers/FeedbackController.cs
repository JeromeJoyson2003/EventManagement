﻿using EventManagementAPI.Models;
using EventManagementAPI.Services;
using Microsoft.AspNetCore.Mvc;
using static EventManagementAPI.Services.FeedbackService;

namespace EventManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackController : ControllerBase
    {
        private readonly FeedbackService _feedbackService;

        // Constructor Injection
        public FeedbackController(FeedbackService feedbackService)
        {
            _feedbackService = feedbackService;
        }

        
        [HttpGet("Get-feedbacks-by-eventid/{eventid:int}")]
        public IActionResult GetFeedbacks([FromRoute] int eventid)
        {
            if (eventid <= 0)
            {
                return BadRequest(new { message = "Invalid event ID. Event ID must be a positive integer." });
            }

            var feedbacks = _feedbackService.ViewFeedbacksWithUserNames(eventid);
            if (feedbacks == null || feedbacks.Count == 0)
            {
                return NotFound(new { message = "No feedbacks found for the given event ID." });
            }

            return Ok(feedbacks);
        }

        [HttpGet("{feedbackId}")]
        public ActionResult<object> GetFeedbackById(int feedbackId)
        {
            var feedbackDetails = _feedbackService.GetFeedbackByIdWithUserName(feedbackId);
            if (feedbackDetails == null)
            {
                return NotFound(new { message = "Feedback not found." });
            }
            return Ok(feedbackDetails);
        }


        //[Authorize(Policy = "UserOnly")]
        [HttpPost("Add-feedbacks-by-Ticketid")]
        public IActionResult AddFeedback([FromForm] FeedbackDTO feedback, int userid, int ticketid)
        {
            Event e = new Event();
            if (DateTime.UtcNow < e.EndDate)
            {
                return BadRequest("The event is ongoing");
            }

            _feedbackService.AddFeedback(feedback, userid, ticketid);
            return Ok(new { message = "Feedback added successfully" });
        }
        [HttpGet("ticket/{userId}/{eventId}")]
        public ActionResult<int> GetTicketIdByUserAndEvent(int userId, int eventId)
        {
            var ticketId = _feedbackService.GetTicketIdByUserAndEvent(userId, eventId);
            if (ticketId == null)
            {
                return NotFound(new { message = "No ticket found for the specified user and event." });
            }
            return Ok(ticketId);
        }


        //[Authorize(Policy = "UserOnly")]
        [HttpGet("average-rating/{eventId}")]
        public IActionResult GetAverageRating(int eventId)
        {
            var averageRating = _feedbackService.GetAverageRating(eventId);
            return Ok(new { averageRating });
        }

        //[Authorize]
        [HttpGet("rating-counts/{eventId}")]
        public IActionResult GetRatingCounts(int eventId)
        {
            var ratingCounts = _feedbackService.GetRatingCounts(eventId);
            return Ok(ratingCounts);
        }

        //[Authorize(Policy = "UserOnly")]
        [HttpDelete("{feedbackId}")]
        public IActionResult DeleteFeedback(int feedbackId, int eventid)
        {
            var result = _feedbackService.DeleteFeedbacks(feedbackId, eventid);
            return Ok(result);
        }
        [HttpGet("is-event-booked/{userId}/{eventId}")]
        public IActionResult IsEventBooked(int userId, int eventId)
        {
            if (userId <= 0 || eventId <= 0)
            {
                return BadRequest(new { message = "Invalid user ID or event ID. Both must be positive integers." });
            }

            var isBooked = _feedbackService.IsEventBookedByUser(userId, eventId);
            return Ok(new { isBooked });
        }
        [HttpGet("feedback-status/{ticketId}")]
        public IActionResult GetFeedbackStatus(int ticketId)
        {
            if (ticketId <= 0)
            {
                return BadRequest(new { message = "Invalid ticket ID. Ticket ID must be a positive integer." });
            }

            var feedbackExists = _feedbackService.FeedbackExistsByTicketId(ticketId);
            return Ok(new { feedbackExists });
        }
    }
}
