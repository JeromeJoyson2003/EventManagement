﻿// These are the namespaces we need to use features like controllers, authorization, and custom services.
using Microsoft.AspNetCore.Mvc; // For building web APIs
using Microsoft.AspNetCore.Authorization; // For restricting access based on user roles
using EventManagementAPI.Models.DTOs; // For using the EventDto data transfer object
using EventManagementAPI.Services; // For using the IEventService interface

namespace EventManagementAPI.Controllers
{
    // This tells ASP.NET Core that this class is an API controller.
    [ApiController]

    // This sets the base URL for all endpoints in this controller to "api/events".
    [Route("api/events")]
    public class EventsController : ControllerBase
    {
        // This is a private field to hold the event service instance.
        private readonly IEventService _eventService;

        // This is the constructor. ASP.NET Core will automatically inject an IEventService when creating this controller.
        public EventsController(IEventService eventService)
        {
            _eventService = eventService; // Save the injected service so we can use it in our methods.
        }

        // This endpoint allows only Admins to create events.
        //[Authorize(Roles = "Admin")]
        [HttpPost("create")] // This handles POST requests to "api/events/create"
        public async Task<IActionResult> CreateEvent([FromBody] EventDto dto)
        {
            // Call the service to create the event using the data from the request body.
            var success = await _eventService.CreateEventAsync(dto);

            // If creation failed, return a 400 Bad Request response.
            if (!success) return BadRequest("Event creation failed.");

            // If successful, return a 200 OK response.
            return Ok("Event created successfully.");
        }

        // This endpoint returns all events. No authorization required.
        [HttpGet("all")] // Handles GET requests to "api/events/all"
        public async Task<IActionResult> GetAllEvents()
        {
            // Get all events from the service.
            var events = await _eventService.GetAllEventsAsync();

            // Return the list of events with a 200 OK response.
            return Ok(events);
        }

        // This endpoint returns a specific event by its ID.
        [HttpGet("{id}")] // Handles GET requests like "api/events/5"
        public async Task<IActionResult> GetEventById(int id)
        {
            // Get the event with the given ID.
            var evnt = await _eventService.GetEventByIdAsync(id);

            // If not found, return a 404 Not Found response.
            if (evnt == null) return NotFound("Event not found.");

            // If found, return the event with a 200 OK response.
            return Ok(evnt);
        }

        // This endpoint allows Admins to update an event.
        //[Authorize(Roles = "Admin")]
        [HttpPut("update/{id}")] // Handles PUT requests like "api/events/update/5"
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] EventDto dto)
        {
            // Try to update the event with the given ID.
            var updated = await _eventService.UpdateEventAsync(id, dto);

            // If update failed (event not found), return 404.
            if (!updated) return NotFound("Event not found.");

            // If successful, return a 200 OK response.
            return Ok("Event updated successfully.");
        }

        // This endpoint allows Admins to delete an event.
        //[Authorize(Roles = "Admin")]
        [HttpDelete("delete/{id}")] // Handles DELETE requests like "api/events/delete/5"
        public async Task<IActionResult> DeleteEvent(int id)
        {
            // Try to delete the event with the given ID.
            var deleted = await _eventService.DeleteEventAsync(id);

            // If deletion failed (event not found), return 404.
            if (!deleted) return NotFound("Event not found.");

            // If successful, return a 200 OK response.
            return Ok("Event deleted successfully.");
        }
    }
}
