﻿    using System.Net.Sockets;

    namespace EventManagementAPI.Models
    {
        public class User
        {
            public int UserID { get; set; }
            public string Name { get; set; }
            public string Email { get; set; }
            public string Password { get; set; }
            public string ContactNumber { get; set; }
            public string Role { get; set; }  // "User" or "Admin"
            public ICollection<Feedbacks> Feedbacks { get; set; }
            public ICollection<Notifications> Notifications { get; set; }
            public ICollection<Payments> Payments { get; set; }
            public ICollection<Tickets> Tickets { get; set; }
        }
    }
    